<?php

	date_default_timezone_set( 'Australia/Sydney' );

	// Mysql syslog database config
	$mysql_server = '127.0.0.1';
	$mysql_database = '';
	$mysql_user = '';
	$mysql_password = '';

	// Site Settings
	$site_name = 'System Logs';

	// Database Settings
	$keep_logs_for_days = 90;

?>
